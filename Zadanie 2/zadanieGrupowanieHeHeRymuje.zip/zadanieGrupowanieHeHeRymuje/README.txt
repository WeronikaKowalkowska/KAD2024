CHARAKTERYSTYKA ZBIORU IRYSÓW

Liczba obserwacji: 150

Atrybuty (kolumny):
1. długość działki kielicha (ang. sepal length) [cm]
2. szerokość działki kielicha (ang. sepal width) [cm]
3. długość płatka (ang. petal length) [cm]
4. szerokość płatka (ang. petal width) [cm]
